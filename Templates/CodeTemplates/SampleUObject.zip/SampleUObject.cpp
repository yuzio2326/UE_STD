﻿#include "$safeitemname$.h"

U$safeitemname$::U$safeitemname$()
{

}

U$safeitemname$::~U$safeitemname$()
{
	
}