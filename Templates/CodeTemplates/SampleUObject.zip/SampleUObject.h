﻿#pragma once
// AssortRock Inc.

#include "CoreMinimal.h"
#include "$safeitemname$.generated.h"

UCLASS()
class YOUR_API U$safeitemname$ : public UObject
{
	GENERATED_BODY();

public:
	U$safeitemname$();
	~U$safeitemname$();
};